Goal: Move the truck to the specified exit within the given "world time". Successfully completing one "recipe" (a set of ordered ingredients) will grant you one movement of the truck. The truck being on one of the adjacent tiles to the enemies triggers the "enemy timer" and so you must escape the enemy-adjacent tiles within the given time amount.

Truck movement: WASD Key
	- W: Forward in the truck's perspective
	- S: Backward
	- A: counter-clockwise turn
	- D: clockwise turn

Reset:
	Pressing the R key resets the game.

Cooking control:
	Click on the right ingredients in the correct order of the "recipe" that show up on top of the lower section of the screen which represents the kitchen (with the two ingredient buttons: carrot and potato)

Level editing:
	Clicking on the tiles that are not the exit nor the current player's location will make the tile an obstacle tile (red tinted). Clicking them again will toggle them back to a normal tile.